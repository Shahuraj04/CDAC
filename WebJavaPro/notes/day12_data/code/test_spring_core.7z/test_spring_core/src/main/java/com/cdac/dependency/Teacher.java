package com.cdac.dependency;

public interface Teacher {
	void teach();
}
