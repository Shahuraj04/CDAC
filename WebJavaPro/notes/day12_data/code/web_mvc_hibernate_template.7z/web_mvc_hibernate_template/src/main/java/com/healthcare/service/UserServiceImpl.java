package com.healthcare.service;

import java.util.List;

import com.healthcare.entities.User;

public class UserServiceImpl implements UserService {

	@Override
	public List<User> listUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User signIn(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
