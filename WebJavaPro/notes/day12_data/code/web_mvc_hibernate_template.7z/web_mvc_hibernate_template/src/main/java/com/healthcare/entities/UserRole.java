package com.healthcare.entities;

public enum UserRole {
	ROLE_DOCTOR, ROLE_PATIENT, ROLE_ADMIN
}
