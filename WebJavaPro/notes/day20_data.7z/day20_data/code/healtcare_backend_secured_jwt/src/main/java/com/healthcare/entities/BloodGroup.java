package com.healthcare.entities;

public enum BloodGroup {
	A_POSITIVE, B_POSITIVE, AB_POSITIVE, O_POSITIVE, A_NEGATIVE, B_NEGATIVE, AB_NEGATIVE, O_NEGATIVE
}
