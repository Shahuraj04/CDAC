package com.healthcare.entities;

public enum Gender {
	MALE, FEMALE, OTHER
}
