package com.healthcare.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.AllArgsConstructor;

/*to declare spring configuration class - to be able to add Spring beans (@Bean)
*/
@Configuration
@EnableWebSecurity // to enable spring security
@EnableMethodSecurity // enables the customization of spring sec support at the method level.
@AllArgsConstructor
public class SecurityConfiguration {
	private final PasswordEncoder passwordEncoder;
	private CustomJwtFilter customJwtFilter;

	/*
	 * Configure a bean to customize Spring security filter chain.
	 */
	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		// 1. disable CSRF protection
		http.csrf(csrf -> csrf.disable());
		// 2. session creation policy - stateless (i.e Spring Security will NOT create
		// HttpSession)
		http.sessionManagement(sessionConfig -> sessionConfig.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

		// 4. Specify URL based authorization rules
		http.authorizeHttpRequests(request -> request
				.requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/users/signin", "/patients/signup",
						"/doctors/signup")
				.permitAll().requestMatchers("/patients/**").hasRole("PATIENT").requestMatchers("/doctors/**")
				.hasRole("DOCTOR").requestMatchers("/admin/**").hasRole("ADMIN").anyRequest().authenticated());
		http.addFilterBefore(customJwtFilter, UsernamePasswordAuthenticationFilter.class);
		return http.build();
	}

	/*
	 * Configure AuthenticationManager as spring bean
	 * 
	 */
	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

}
