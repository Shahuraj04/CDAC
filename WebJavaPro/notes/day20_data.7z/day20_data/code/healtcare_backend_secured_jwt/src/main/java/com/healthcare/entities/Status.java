package com.healthcare.entities;

public enum Status {
	SCHEDULED, CANCELLED,COMPLETED
}
