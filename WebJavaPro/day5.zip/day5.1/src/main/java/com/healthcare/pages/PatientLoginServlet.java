package com.healthcare.pages;

import java.io.IOException;
import java.io.PrintWriter;

import com.healthcare.dao.DoctorDao;
import com.healthcare.dao.DoctorDaoImpl;
import com.healthcare.dao.PatientDao;
import com.healthcare.dao.PatientDaoImpl;
import com.healthcare.pojos.Doctor;
import com.healthcare.pojos.Patient;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class PatientLoginServlet
 */
@WebServlet(value = "/authenticate", loadOnStartup = 1)
public class PatientLoginServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.sendRedirect("patient_dashboard");
	}

	private static final long serialVersionUID = 1L;
	private PatientDao patientDao;
	private DoctorDao doctordao;

	/**
	 * @see Servlet#init()
	 */
	public void init() throws ServletException {
		try {
			System.out.println("in init " + getClass());
			// create patient dao instance
			patientDao = new PatientDaoImpl();
			doctordao = new DoctorDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	@Override
	public void destroy() {
		try {
			// patient dao instance - clean up
			patientDao.cleanUp();
		} catch (Exception e) {
			// e.printStackTrace();
			throw new RuntimeException("err in destroy " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// set cont type ,
		response.setContentType("text/html");
		// get pw
		try (PrintWriter pw = response.getWriter()) {
			// get rq params - email , password
			String pat_email = request.getParameter("em");
			String pat_password = request.getParameter("pass");
			// invoke dao's sign in method
			String doc_email = request.getParameter("doc_em");
			String doc_password = request.getParameter("doc_pass");
			Patient patient = patientDao.signIn(pat_email, pat_password);
			Doctor doctor = doctordao.docSignIn(doc_email, doc_password);
			// -> not null=> success -> login success mesg
			String loginName = request.getParameter("login");
			if ("patient".equals(loginName)) {
				if (patient == null) {
					// invalid login --> retry link -> login.html
					pw.print("<h5> Invalid Login , Please <a href='login.html'>Retry</a></h5>");

				} else {
					// 1. Get HttpSession from WC
					HttpSession session = request.getSession();
					System.out.println("session is new " + session.isNew());// t
					System.out.println("Session ID " + session.getId());// unique id
					System.out.println("patient details - " + session.getAttribute("patient_details"));// null
					// 2. save patient details under HttpSession
					session.setAttribute("patient_details", patient);
					// redirect client -> dashboard page
					response.sendRedirect("patient_dashboard");

				}

			} else if ("doctor".equals(loginName)) {
				if (doctor == null) {
					// invalid login --> retry link -> login.html
					pw.print("<h5> Invalid Login , Please <a href='doctorlogin.html'>Retry</a></h5>");

				}else {
					// 1. Get HttpSession from WC
					HttpSession session = request.getSession();
					System.out.println("session is new " + session.isNew());// t
					System.out.println("Session ID " + session.getId());// unique id
					System.out.println("Doctor details - " + session.getAttribute("doctor_details"));// null
					// 2. save patient details under HttpSession
					session.setAttribute("doctor_details", doctor);
					// redirect client -> dashboard page
					
					//System.out.println(session.getAttribute("doctor_details"));
					response.sendRedirect("patient_dashboard");

				}

			}

		} catch (Exception e) {
			throw new ServletException("err in do-post " + getClass(), e);
		}

	}

}
