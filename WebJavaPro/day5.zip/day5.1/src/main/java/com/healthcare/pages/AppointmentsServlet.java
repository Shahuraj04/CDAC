package com.healthcare.pages;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.apache.coyote.Request;

import com.healthcare.dao.AppointmentDao;
import com.healthcare.dao.AppointmentDaoImpl;
import com.healthcare.pojos.Patient;

/**
 * Servlet implementation class AppointmentsServlet
 */
@WebServlet(value = "/appointments", loadOnStartup = 3)
public class AppointmentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AppointmentDao appointmentDao;

	@Override
	public void destroy() {
		try {
			appointmentDao.cleanUp();
		} catch (Exception e) {
			throw new RuntimeException("err in destroy " + getClass(), e);
		}
	}

	@Override
	public void init() throws ServletException {
		try {
			appointmentDao = new AppointmentDaoImpl();
		} catch (Exception e) {
			// to inform WC - about init's failure
			throw new ServletException("err in init " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// set reps cont type
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get session from WC
			HttpSession session = request.getSession();
			System.out.println("from " + getClass() + " session is new " + session.isNew());
			Patient patient = (Patient) session.getAttribute("patient_details");
			// get req parameters
			
			String action1 = request.getParameter("action");
			int doctorId = Integer.parseInt(request.getParameter("doc_id"));
			String timeStamp = request.getParameter("appointment_ts");
			
			System.out.println(timeStamp);
			
			
			Timestamp ts = Timestamp.valueOf(LocalDateTime.parse(timeStamp));
			
			
			if (action1.equals("book")) {
				
				
				// book appointment- call dao's method
				String message = appointmentDao.bookAppointment(doctorId, patient.getId(), ts);
				// add session scoped attribute
				session.setAttribute("mesg", message);
				response.sendRedirect("patient_dashboard");

			}
//			else if (action1.equals("cancel")) {
//					pw.print("deleyred");
//			}
		} catch (Exception e) {
			throw new ServletException("err in do post " + getClass(), e);
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int appointmentID = Integer.parseInt(req.getParameter("id"));
		HttpSession session = req.getSession();
		int patientId = ((Patient) session.getAttribute("patient_details")).getId();
		try {
			String msg = appointmentDao.cancelAppointment(appointmentID, patientId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
