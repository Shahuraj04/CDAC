package com.ecommerce.validations;


public class EcommerceValidations{
	
	
	
}