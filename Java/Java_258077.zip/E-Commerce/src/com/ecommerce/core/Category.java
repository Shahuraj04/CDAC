package com.ecommerce.core;

public enum Category {
	ELECTRONICS,CLOTHING,GROCERY,BOOKS;
}
