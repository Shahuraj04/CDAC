package com.ecommerce.CustomException;

public class ECommerceException extends Exception{

	public ECommerceException(String msg) {
		super(msg);
	}
	
	
	
	
}