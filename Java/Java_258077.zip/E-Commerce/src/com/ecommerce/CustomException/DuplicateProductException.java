package com.ecommerce.CustomException;

import java.util.List;

import com.ecommerce.core.Category;
import com.ecommerce.core.Product;

public class DuplicateProductException{
		
	
	
}