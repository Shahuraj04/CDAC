package ExceptionHandling;

public class SpeedException extends Exception{
	
	public SpeedException(String msg) {
		super(msg);
	}
	
}