package p2;

public interface B {
	boolean checkPrime(int number);
}
