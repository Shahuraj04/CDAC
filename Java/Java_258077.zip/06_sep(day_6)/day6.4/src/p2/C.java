package p2;

public interface C extends A,B{
 double calc(double a , double b);
}
