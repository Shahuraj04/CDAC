package p2;

public class D implements C{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean checkPrime(int number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double calc(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
