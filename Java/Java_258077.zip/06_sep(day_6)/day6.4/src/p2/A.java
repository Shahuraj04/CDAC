package p2;

public interface A {
 void show();
}
