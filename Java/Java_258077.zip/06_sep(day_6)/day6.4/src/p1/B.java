package p1;

public interface B {
	int DATA = 200;
	double compute(double a, double b);
}
