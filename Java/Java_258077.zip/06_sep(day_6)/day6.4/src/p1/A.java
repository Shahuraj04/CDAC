package p1;

public interface A {
	int DATA = 100;

	double compute(double a, double b);
}
