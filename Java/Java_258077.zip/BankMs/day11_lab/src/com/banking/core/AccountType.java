package com.banking.core;

public enum AccountType {
	SAVING, CURRENT
}
