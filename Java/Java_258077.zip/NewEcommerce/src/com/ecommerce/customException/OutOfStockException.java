package com.ecommerce.customException;

public class OutOfStockException extends ECommerceException {

	public OutOfStockException(String msg) {
		super(msg);
	}
}
