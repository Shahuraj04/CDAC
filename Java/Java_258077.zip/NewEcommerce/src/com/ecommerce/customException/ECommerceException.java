package com.ecommerce.customException;
import java.lang.Exception;

public class ECommerceException extends Exception{
	
	public ECommerceException(String msg) {
		super(msg);
	}
}
