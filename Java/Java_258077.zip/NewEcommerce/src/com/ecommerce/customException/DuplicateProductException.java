package com.ecommerce.customException;

public class DuplicateProductException extends ECommerceException {

	public DuplicateProductException(String msg) {
		super(msg);
		
	}

}
