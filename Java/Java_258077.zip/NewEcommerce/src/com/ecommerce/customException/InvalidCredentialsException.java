package com.ecommerce.customException;

public class InvalidCredentialsException extends ECommerceException {
	public InvalidCredentialsException(String msg) {
		super(msg);
	}

}
