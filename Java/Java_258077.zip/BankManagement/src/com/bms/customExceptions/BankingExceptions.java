package com.bms.customExceptions;

public class BankingExceptions extends Exception{

	public BankingExceptions(String msg) {
		super(msg);
	}
	
	
}