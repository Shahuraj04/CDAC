package com.sms.custom_exception;

public class SMSCustomException extends Exception {
	
	public SMSCustomException (String msg) {
		super(msg);
		
	}

}
