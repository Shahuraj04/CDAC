package com.service;

import static com.validation.validation.validateAll;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.core.ShoeGallery;
import com.core.ShoeType;
import com.exception.MyException;

public class ShoeServiceImpl implements ShoeService {

	private Map<Integer, ShoeGallery> map = new HashMap<>();

		
		public ShoeServiceImpl() {
		    List<ShoeGallery> list = new ArrayList<>();

		    list.add(new ShoeGallery("AirZoom", "Nike", 9, 9500.0, true, ShoeType.SPORT));
		    list.add(new ShoeGallery("ClassicLow", "Adidas", 8, 7200.0, false, ShoeType.CASUAL));
		    list.add(new ShoeGallery("LeatherPro", "Puma", 7, 8500.0, true, ShoeType.FORMAL));
		    list.add(new ShoeGallery("StreetFlex", "Skechers", 6, 6400.0, true, ShoeType.CASUAL));
		    list.add(new ShoeGallery("AirMaxPro", "Nike", 10, 12000.0, true, ShoeType.SPORT));
		    
		    for (ShoeGallery s : list) {
		        map.put(s.getShoeid(), s);
		    }

		
		}

		
	

	@Override
	public String addShoe(String name, String brand, int rating, double price, boolean available, String type)
			throws MyException {

		ShoeGallery s = validateAll(name, brand, rating, price, available, type);
		map.put(s.getShoeid(), s); // essential to persist the record
		
		return "SHOE ADDED IN COLLECTION";
	}

	@Override
	public void display() {
		for (ShoeGallery s : map.values()) {
			System.out.println(s);
		}
	}

	// sort by id
	@Override
	public void sortbyid() {
		TreeMap<Integer, ShoeGallery> sorted = new TreeMap<>(map);
		for (ShoeGallery s : sorted.values()) {
			System.out.println(s);
		}

		// or
		// ShoeGallery s= map.values().streams().
		// .sorted((s1, s2) -> Integer.compare(s1.getShoeId(), s2.getShoeId()));
		// System.out.println(s);

	}

	@Override
	public void getExpensive() throws MyException {
		if (map.isEmpty()) {
			throw new MyException("Collection is empty");
		}

		ShoeGallery max = null;

		for (ShoeGallery s : map.values()) {
			if (max == null || s.getPrice() > max.getPrice()) {
				max = s;
			}
		}

		System.out.println("Most expensive shoe: " + max);
	}

	@Override
	public void removeUnavailableShoes() throws MyException {
		if (map.isEmpty()) {
			throw new MyException("Gallery is empty");
		}

		map.values().removeIf(shoe -> !shoe.isAvailable());
		System.out.println("Unavailable shoes removed successfully.");
	}

	@Override
	public void updatePrice(String brand, double newPrice) throws MyException {
		boolean found = false;
		for (ShoeGallery s : map.values()) {
			if (s.getBrand().equalsIgnoreCase(brand)) {
				s.setPrice(newPrice);
				found = true;
			}
		}
		if (!found) {
			throw new MyException("NO SUCH BRAND EXISTS");
		}
		System.out.println("PRICE UPDATED SUCCESSFULLY");
	}

	@Override
	public void sortbypricedesc() {
		map.values().stream().sorted((s1, s2) -> Double.compare(s2.getPrice(), s1.getPrice()))
				.forEach(s -> System.out.println(s));
	}

}
