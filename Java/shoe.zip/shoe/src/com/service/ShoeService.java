package com.service;

import com.exception.MyException;

public interface ShoeService {
	String addShoe(String name, String brand, int rating, double price, boolean available, String type) throws MyException;
	void sortbypricedesc() ;
	void updatePrice(String brand,double newPrice) throws MyException;
	void removeUnavailableShoes() throws MyException;
	void getExpensive() throws MyException;
	void display() ;
	void sortbyid();
}
