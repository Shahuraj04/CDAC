package com.core;

public class ShoeGallery {

	private int shoeid;
	private String name;
	private String brand;
	private int rating;
	private double price;
	private boolean available;
	private ShoeType type;

	private static int idgenrator = 1;

	public ShoeGallery(String name, String brand, int rating, double price, boolean available, ShoeType type) {
		super();
		this.shoeid = idgenrator++;
		this.name = name;
		this.brand = brand;
		this.rating = rating;
		this.price = price;
		this.available = available;
		this.type = type;
	}

	@Override
	public String toString() {
		return "ShoeGallery [shoeid=" + shoeid + ", name=" + name + ", brand=" + brand + ", rating=" + rating
				+ ", price=" + price + ", available=" + available + ", type=" + type + "]";
	}

	public ShoeGallery(int shoeid) {
		super();
		this.shoeid = shoeid;
	}

	public int getShoeid() {
		return shoeid;
	}

	public void setShoeid(int shoeid) {
		this.shoeid = shoeid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public ShoeType getType() {
		return type;
	}

	public void setType(ShoeType type) {
		this.type = type;
	}

	public static int getIdgenrator() {
		return idgenrator;
	}

	public static void setIdgenrator(int idgenrator) {
		ShoeGallery.idgenrator = idgenrator;
	}

}
