package com.core;

public enum ShoeType {
FORMAL,CASUAL,SPORT;
}
