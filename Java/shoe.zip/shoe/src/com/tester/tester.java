package com.tester;

import java.util.Scanner;

import com.service.ShoeService;
import com.service.ShoeServiceImpl;

public class tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Scanner sc= new Scanner(System.in)){
			
			ShoeService service= new ShoeServiceImpl();
			
			boolean exit=false;
			
			while(!exit) {
				
				System.out.println("SHOE GALLERY");
				System.out.println("1) Add a new Shoe record to the collection. (Add at least 4 new records in collection)\r\n"
						+ "2) Display all Shoe details.\r\n"
						+ "3) Display all Shoe details sorted by Shoe id.\r\n"
						+ "4) Search Shoe which is most expensive in Gallery.\r\n"
						+ "5) Remove Shoes that are not available in the Gallery.\r\n"
						+ "6) Update Shoe price based on brand.\r\n"
						+ "7) Sort Shoe data as per price in descending order.\r\n"
						+ "8) Exit from application.\r\n"
						+ "");
				
				System.out.println("enter your choice : ");
				
				try {
					
					switch(sc.nextInt()) {
					case 1:
					
						break;
						
					case 2:
						service.display();
						break;
						
					case 3:
						service.sortbyid();
						break;
						
					case 4: 
						service.getExpensive();
						break;
						
					case 5:
						service.removeUnavailableShoes();
						break;
						
					case 6:
						service.updatePrice(sc.next(), sc.nextDouble());
						break;
						
					case 7:
						service.sortbypricedesc();
						break;
						
					case 8:
						exit =true;
						break;
						
					default :
						System.out.println("enter valid choice");
						break;
					}
					
				}catch(Exception e) {
					e.getStackTrace();
					sc.nextLine();
				}
			}
		}
	}

}
