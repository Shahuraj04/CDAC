package com.validation;

import com.core.ShoeGallery;
import com.core.ShoeType;
import com.exception.MyException;

public class validation {
	
	public static ShoeGallery validateAll(String name, String brand, int rating, double price, boolean available,
			String type) throws MyException {
		validateRating(rating);
		ShoeType st= validatetype(type);
		namelength(name);
		return new ShoeGallery(name, brand, rating, price, available, st);
		
	}
	
	//validating ratings
	public static void validateRating(int rating ) throws MyException {
		
			if(rating>10 || rating <1) {
				throw new MyException("InvalidException");
			}
		
	}
	
	public static void namelength(String name ) throws MyException {
		if(name.length()>20 || name.length() <3) {
			throw new MyException("INVALID NAME FORMAT");
		}
		
	}
	
	public static ShoeType validatetype(String type) throws MyException {
		
		ShoeType shoetype= ShoeType.valueOf(type.toUpperCase());
		
		for(ShoeType s: ShoeType.values()) {
			if(s.equals(shoetype)) {
				return shoetype;
			}
		}
		throw new MyException("INVALID SHOE TYPE!!!!");
	}
	
}
