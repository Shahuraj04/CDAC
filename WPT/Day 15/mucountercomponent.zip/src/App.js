import logo from './logo.svg';
import './App.css';
import MyHeader from "./components/MyHeader"
import MyFooter,{MyF1} from './components/MyFooter';
import MyClassCounterComponent from './components/MyClassCounterComponent';
import MyFunctionCounterComponent from './components/MyFunctionCounterComponent';
function App() {
  return (
    <>
        <MyHeader/>
        <MyF1></MyF1>
        <MyClassCounterComponent/>
        <MyFunctionCounterComponent/>
        <MyFooter/>
    </>
  );
}

export default App;
