import React, { Component } from 'react'

export default class MyClassCounterComponent extends Component {
    constructor(props){
        super(props)
        this.state={name:"Kishori",count:0}
       
        this.incrementcnt=this.incrementcnt.bind(this)
    }
 //when we use old style function syntax, then we loose the referece of class object, hence we get error, this object  is undefined
 //to avoid error use bind function inside constructor refer line 8
    incrementcnt(){
        /*this.setState({...this.state,count:this.state.count+1},()=>{
            console.log("count : "+this.state.count)
        })*/
        this.setState((prevState)=>{
            return {...prevState,count:prevState.count+1}
        },()=>{
            console.log("count : "+this.state.count)
        })
    }
    //incrementcnt=()=>{
    ////to modify state always use setState function, and to see the updated value use callback function  
    //  this.setState({...this.state,count:this.state.count+1},()=>{
    //        console.log(this.state.count)
    //    })
        
    //}

    decrementcnt=()=>{
        this.setState({...this.state,count:this.state.count>0?this.state.count-1:0},()=>{
            console.log("count: "+this.state.count)
        })
    }
    resetcnt=()=>{
        this.setState({...this.state,count:0},()=>{
            console.log("count: "+this.state.count)
        })
    }
    render() {
    return (
      <div>
        <h1>Class Component</h1>
        <button type="button" name="btn" id="inc" value="inc" onClick={this.incrementcnt}>Increament</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="btn" id="decr" value="decr" onClick={this.decrementcnt}>Decreament</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="btn" id="reset" value="reset" onClick={this.resetcnt}>Reset</button>

        <p>You clicked {this.state.count} times</p>
      </div>
    )
  }
}
