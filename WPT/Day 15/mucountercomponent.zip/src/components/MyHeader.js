import React from 'react'

 const MyHeader=(props)=> {
  return (
    <div><h1 style={{backgroundColor:"blue",color:"white",border:"2px solid red"}}>This is counter application</h1></div>
  )
}
export default MyHeader
