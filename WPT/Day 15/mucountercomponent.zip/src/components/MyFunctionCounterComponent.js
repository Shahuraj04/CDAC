import React,{useState,useEffect} from 'react'

export default function MyFunctionCounterComponent(props) {
//useState is hook which retrun a array of size 2 
//1 st value is initial value, ans second value is reference to setter method

    const [count,setCount] =useState(0);
    const increment=()=>{
        setCount(count+1)
       
    }
    const decrement=()=>{
        setCount(count>0?count-1:0)
    }
    const resetcount=()=>{
        setCount(0)
    }

    //initialization, this useEffect will get executed only once in the lifecycle of the component
    useEffect(()=>{
        console.log("in initialization useEffect")
    },[])

    //it will call callback function in mouting phase 
    //and then in updating phase, when value of count state changes, then for every change callback function gets called once
    useEffect(()=>{
        console.log("coutn in function incr:"+count)
    },[count])
    
  return (
    <div>
        <h1>Function Component</h1>
        <button type="button" name="inc"  id="inc" value="inc" onClick={increment}>increment</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="decr"  id="decr" value="decr" onClick={decrement}>decrement</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="reset"  id="reset" value="reset" onClick={resetcount}>Reset</button>&nbsp;&nbsp;&nbsp;&nbsp;
        <p>You clicked {count} times</p>
    </div>
  )
}
