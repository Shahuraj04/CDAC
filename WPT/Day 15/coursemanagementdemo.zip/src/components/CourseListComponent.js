import React from 'react'

export default function CourseListComponent(props) {
  return (
    <div>
        <ul>
            
           {/* display searcharr of app.js in unorderd list form */} {props.arr.map((val,index)=><li key={index}>{val}</li>)}
        </ul>
    </div>
  )
}
