import React,{useState} from 'react'

export default function CourseFormComponent(props) {
    const [formdetails,setformdetails]=useState({cname:""})
    // gets called for onChange event
    const handlechange=(event)=>       {
        console.log("in handlechange")
        setformdetails({...formdetails,cname:event.target.value})}

        //add a course in arr in APP.js
    const addcourse=()=>{
        if(formdetails.cname==="" || formdetails.cname.trim().length===0){
            alert("corsename cannot be empty")
           
        }else{
            //pass data to App.js i.e parent component
            props.insertCourse(formdetails.cname)
             //clear text box
            setformdetails({...formdetails,cname:""})
        }
    }

    //delete course from array in App.js
    const deletecourse=()=>{
        if(formdetails.cname==="" || formdetails.cname.trim().length===0){
            alert("coursename cannot be empty");
        }else{
            //pass data to App.js i.e parent component
            props.deleteCourse(formdetails.cname);
            //clear text box
            setformdetails({...formdetails,cname:""})
        }
    }

    const updatecourse=()=>{
        if(formdetails.cname==="" || formdetails.cname.trim().length===0){
            alert("coursename cannot be empty")
        }else{
            var newcname=prompt("enetr new course name")
            props.updatecourse(formdetails.cname,newcname)
             //clear text box
            setformdetails({...formdetails,cname:""})
        }
    }
  return (
    <div>
        <form>
            <div className="form-group">
                <label htmlFor="course">Course Name</label>
                <input type="text" className="form-control" name="cname" id="course"
                value={formdetails.cname}
                onChange={handlechange}/>
            </div>
              <button type="button" id="add" name="add" className="btn btn-primary" onClick={addcourse}>Add course</button>

              <button type="button" id="del" name="del" className="btn btn-primary" onClick={deletecourse}>Delete course</button>


              <button type="button" id="update" name="update" className="btn btn-primary" onClick={updatecourse}>update course</button>
        </form>
    </div>
  )
}
