import { useState,useEffect } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import CourseListComponent from './components/CourseListComponent';
import CourseFormComponent from './components/CourseFormComponent'
function App() {
  const [coursearr,setcoursearr]=useState(["Java","Python","Databases"])
const [searcharr,setsearcharr]=useState([])
const [searchtxt,setsearchtxt]=useState("");

  useEffect(()=>{
setsearcharr([...coursearr])
  },[coursearr])

  useEffect(()=>{
    if(searchtxt===""){
      setsearcharr([...coursearr])
    }else{
      const arr=coursearr.filter(c=>c.includes(searchtxt))
      setsearcharr([...arr])
    }
  },[searchtxt])

  const addNewCourse=(cnm)=>{
    console.log("addNewCourse course name: "+cnm)
    setcoursearr([...coursearr,cnm])
  }

  const removeCourse=(cnm)=>{
    console.log("in deleteCourse App.js "+cnm)
    const arr=coursearr.filter(nm=>nm!=cnm)
    setcoursearr([...arr])
  }
  const modifycourse=(oldname,newname)=>{
     const arr=coursearr.map(c=>c===oldname?newname:c)
     setcoursearr([...arr]);
  }
  const handleChange=(ev)=>{
      setsearchtxt(ev.target.value)
  }
  return (
    <>
    <label htmlFor="search">Search</label> : <input type="text" name="searchtxt" id="search"
    value={searchtxt}
    onChange={handleChange}></input>
    <br/><br/>
    <div className="container">
      <div className="row">
        <div className="col-sm-12 col-md-6">
          <CourseListComponent arr={searcharr}/>
        </div>
        <div className="col-sm-12 col-md-6">
          <CourseFormComponent 
          insertCourse={addNewCourse}
          deleteCourse={removeCourse}
          updatecourse={modifycourse}/>
        </div>
      </div>
    </div>
    </>
  );
}

export default App;
