const express = require('express')
const app = express()
const bodyParser=require('body-parser')
const loginrouter  = require("./router/loginrouter")
const emprouter= require("./router/emprouter")

const cors = require('cors')

app.use(cors())

app.use(bodyParser.json())

app.use("/login",loginrouter)
app.use("/",emprouter)

app.listen(7777,()=>{

    console.log("connection on 7777 port")
})