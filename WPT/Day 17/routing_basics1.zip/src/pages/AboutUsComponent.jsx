import React, { Component } from 'react'

export default class AboutUsComponent extends Component {
  constructor(props){
    super(props)
    console.log("in constructor of aboutus")
    this.state={
      count:1
    }
  }
  //it gets executed only once, hence useful for initialization or API call
  //useEffect(()=>{
    //code for useEffect initialization
  //in useEfect this returned function will get 
  // //executed at the time of unmount 
  //return()=>{}},[])
  componentDidMount(){
     console.log("in componentDidMount")
  }
  //useEffect(()=>{},[count])
  //useEffect(()=>{},[name])
  componentDidUpdate(prevprops,prevstate){
    if(prevstate.count!==this.state.count){
       console.log("not same")
    }
    if(prevstate.name!==this.state.name){
       console.log("not same")
    }
  }
  componentWillUnmount(){
    console.log("in componentWillUnmount")
  }
  render() {
    console.log("in aboutus render")
    return (
      <div>AboutUsComponent</div>
    )
  }
}
