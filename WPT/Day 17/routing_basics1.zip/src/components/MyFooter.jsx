import React from 'react'
import "./MyHeader.css"
export default function MyFooter() {
  return (
    <div>
        <h5 className="myfooter">&copy; Copyrights reserved</h5>
    </div>
  )
}
