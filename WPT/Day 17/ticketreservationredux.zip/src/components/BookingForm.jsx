import React,{useState} from 'react'
import {useDispatch} from 'react-redux'
import { newbooking, cancelbooking } from "../redux/reservationSlice"; // RTK actions

export default function BookingForm() {
  const [formdetails, setformdetails] = useState({id: "",name: "", amount: ""});

  const dispatch = useDispatch();

  const handlechange = (event) => {
    const { name, value } = event.target;
    setformdetails({ ...formdetails, [name]: value });
  };

  const bookticketfunction = () => {
    dispatch(
      newbooking({
        id: formdetails.id,
        name: formdetails.name,
        amount: formdetails.amount
      })
    );
  };

  const cancelticketfunction = () => {
    dispatch(
      cancelbooking({
        id: formdetails.id,
        name: formdetails.name,
        amount: formdetails.amount
      })
    );
  };

  return (
    <div>
      <form>
        Id:
        <input
          type="text"
          name="id"
          onChange={handlechange}
          value={formdetails.id}
        />
        <br />

        Name:
        <input
          type="text"
          name="name"
          onChange={handlechange}
          value={formdetails.name}
        />
        <br />

        Amount:
        <input
          type="text"
          name="amount"
          onChange={handlechange}
          value={formdetails.amount}
        />
        <br />

        <button type="button" onClick={bookticketfunction}>
          Book Ticket
        </button>

        <button type="button" onClick={cancelticketfunction}>
          Cancel Ticket
        </button>
      </form>
    </div>
  );
}
