import React from "react";
import { useSelector } from "react-redux";

function DisplayReservation() {
  const reservationList = useSelector(state => state.railway.reservationList);
  const cancellationList = useSelector(state => state.railway.cancellationList);
  const amount = useSelector(state => state.railway.amount);

  return (
    <div>
      <h2>Reservation List</h2>
      <ul>
        {reservationList.map(r => (
          <li key={r.id}>{r.name} — ₹{r.amount}</li>
        ))}
      </ul>

      <h2>Cancellation List</h2>
      <ul>
        {cancellationList.map(c => (
          <li key={c.id}>{c.name} — ₹{c.amount}</li>
        ))}
      </ul>

      <h2>Total Amount: ₹{amount}</h2>
    </div>
  );
}

export default DisplayReservation;
