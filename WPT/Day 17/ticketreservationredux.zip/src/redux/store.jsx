import { configureStore } from "@reduxjs/toolkit";
import reservationReducer from "./reservationSlice";

const store = configureStore({
  reducer: {
    railway: reservationReducer
  }
});

export default store;
