import {createSlice} from "@reduxjs/toolkit"

const reservationSlice=createSlice({
  name:"reservation",
  initialState:{
    reservationList:[],
    cancellationList:[],
    amount:3000
  },
  reducers:{
    newbooking:(state,action)=>{
        console.log("in newbooking reducers")
        //add data in reservationlist
        state.reservationList.push({...action.payload});
        //add amount in state
        state.amount=state.amount+parseFloat(action.payload.amount)
    },
    cancelbooking:(state,action)=>{
        console.log("in cancel booking reducer")
        //delete from reservation list
        state.reservationList=state.reservationList.filter(ob=>ob.id!=action.payload.id)

        // add into cancellationlist
        state.cancellationList.push({...action.payload})

        //decrease the amount
        state.amount-=action.payload.amount;

    }
  }
})

export const {newbooking,cancelbooking}=reservationSlice.actions

export default reservationSlice.reducer;