import logo from './logo.svg';
import './App.css';
import MyClassComponent from './components/MyClassComponent';
import MyFunctionComponent from './components/MyFunctionComponent';

function App() {
  var ob={color:'white',backgroundColor:'blue'}
  
  return (<div>
    <h1 style={{color:'red',backgroundColor:'yellow'}}>Hello World!</h1>
    <h2 style={ob}>Welcome to react application</h2>
    <h3>Using style via css</h3>
    <MyClassComponent name="Rajan" address="Baner"/>
    <hr color='red' size='2'></hr>
    <MyClassComponent name="Revati" address="Baner"/>
    <MyFunctionComponent num1="10" num2="34"/>
    <MyFunctionComponent num1="50" num2="567"/>
  </div>)
}

export default App;
