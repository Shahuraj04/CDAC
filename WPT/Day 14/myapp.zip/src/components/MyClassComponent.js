import React,{Component, Fragment} from 'react'
class MyClassComponent extends React.Component{
    constructor(props){
        super(props)
        console.log("in MyClassComponent constructor")
    }
    render(){
        console.log("in myclasscomponent render function")
        return(
            <Fragment>
                <h1>Hello From class component {this.props.name}-----{this.props.address}</h1>
                <h2>Welcome to react class component</h2>
            </Fragment>
        )
    }

}

export default MyClassComponent