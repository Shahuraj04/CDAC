const MyFunctionComponent=(props)=>{
    var ans=parseInt(props.num1)+parseInt(props.num2)
  return(
    <div>
        <h1>Hello From function component {props.num1}-------{props.num2}</h1>
        <h2>Welcome to MyFunctionComponent {ans}</h2>
    </div>
  )
}

export default MyFunctionComponent;