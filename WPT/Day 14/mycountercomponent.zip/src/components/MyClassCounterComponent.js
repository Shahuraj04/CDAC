import React, { Component } from 'react'

export default class MyClassCounterComponent extends Component {
    constructor(props){
        super(props)
        this.state={name:"Kishori",count:0}
    }

    incrementcnt=()=>{
    //to modify state always use setState function, and to see the updated value use callback function  
      this.setState({...this.state,count:this.state.count+1},()=>{
            console.log(this.state.count)
        })
        
    }
    render() {
    return (
      <div>
        <button type="button" name="btn" id="inc" value="inc" onClick={this.incrementcnt}>Increament</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="btn" id="decr" value="decr">Decreament</button>&nbsp;&nbsp;&nbsp;&nbsp;

        <button type="button" name="btn" id="reset" value="reset">Reset</button>

        <p>You clicked {this.state.count} times</p>
      </div>
    )
  }
}
