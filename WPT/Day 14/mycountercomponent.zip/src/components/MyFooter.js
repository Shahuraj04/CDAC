import React from 'react'
import "./MyFooter.css"
export default function MyFooter() {
  return (
    <div><h3>This is footer</h3></div>
  )
}

export function MyF1() {
  return (
    <div><h4>This is MyF1</h4></div>
  )
}

