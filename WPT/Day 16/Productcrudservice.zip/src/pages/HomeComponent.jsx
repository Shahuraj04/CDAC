import React from 'react'

export default function HomeComponent() {
  return (
    <div>HomeComponent</div>
  )
}
