import React, { Component } from 'react'

export default class AboutUsComponent extends Component {
  render() {
    return (
      <div>AboutUsComponent</div>
    )
  }
}
