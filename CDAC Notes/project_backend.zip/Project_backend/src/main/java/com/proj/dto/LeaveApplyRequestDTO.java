package com.proj.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LeaveApplyRequestDTO {
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;
    private Long empId;
}
