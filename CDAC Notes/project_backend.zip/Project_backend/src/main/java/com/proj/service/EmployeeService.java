package com.proj.service;

import java.util.List;

import com.proj.dto.DeptResponseDTO;
import com.proj.dto.EmpRequestDTO;
import com.proj.entity.Employee;

public interface EmployeeService {

    DeptResponseDTO addEmployee(EmpRequestDTO empDTO);

    List<Employee> getAllEmployees();

    List<Employee> getEmployeeById(Long empId);

    DeptResponseDTO deleteEmployeeById(Long empId);

    DeptResponseDTO updateEmployee(Long empId, EmpRequestDTO empDto);
}
