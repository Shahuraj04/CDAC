package com.proj.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.proj.dto.LeaveApplyRequestDTO;
import com.proj.dto.LeaveResponseDTO;
import com.proj.entity.LeaveStatus;
import com.proj.service.LeaveService;

@RestController
@RequestMapping("/leaves")
public class LeaveController {

    @Autowired
    private LeaveService leaveService;

    /* Employee applies for leave */
    @PostMapping
    public ResponseEntity<LeaveResponseDTO> applyLeave(
            @RequestBody LeaveApplyRequestDTO dto) {

        return ResponseEntity.ok(leaveService.applyLeave(dto));
    }

    /* HR approves / rejects */
    @PutMapping("/{leaveId}/status")
    public ResponseEntity<LeaveResponseDTO> updateStatus(
            @PathVariable Long leaveId,
            @RequestParam LeaveStatus status,
            @RequestParam Long hrId) {

        return ResponseEntity.ok(
                leaveService.updateLeaveStatus(leaveId, status, hrId)
        );
    }
}
