package com.proj.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.dto.LeaveApplyRequestDTO;
import com.proj.dto.LeaveResponseDTO;
import com.proj.entity.LeaveRequest;
import com.proj.entity.LeaveStatus;
import com.proj.repository.EmpRepository;
import com.proj.repository.HrRepository;
import com.proj.repository.LeaveRepository;

@Service
public class LeaveServiceImpl implements LeaveService {

    @Autowired
    private LeaveRepository leaveRepository;

    @Autowired
    private EmpRepository employeeRepository;

    @Autowired
    private HrRepository hrRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public LeaveResponseDTO applyLeave(LeaveApplyRequestDTO dto) {

        LeaveRequest leave = new LeaveRequest();
        leave.setStartDate(dto.getStartDate());
        leave.setEndDate(dto.getEndDate());
        leave.setReason(dto.getReason());
        leave.setStatus(LeaveStatus.PENDING);

        leave.setEmployee(
                employeeRepository.findById(dto.getEmpId())
                        .orElseThrow(() -> new RuntimeException("Employee not found"))
        );

        LeaveRequest saved = leaveRepository.save(leave);

        LeaveResponseDTO response =
                modelMapper.map(saved, LeaveResponseDTO.class);

        response.setEmpName(saved.getEmployee().getEmp_name());

        return response;
    }

    @Override
    public LeaveResponseDTO updateLeaveStatus(
            Long leaveId,
            LeaveStatus status,
            Long hrId) {

        LeaveRequest leave = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new RuntimeException("Leave not found"));

        if (leave.getStatus() != LeaveStatus.PENDING) {
            throw new RuntimeException("Leave already processed");
        }

        leave.setStatus(status);
        leave.setHr(
                hrRepository.findById(hrId)
                        .orElseThrow(() -> new RuntimeException("HR not found"))
        );

        LeaveRequest updated = leaveRepository.save(leave);

        LeaveResponseDTO response =
                modelMapper.map(updated, LeaveResponseDTO.class);

        response.setEmpName(updated.getEmployee().getEmp_name());

        return response;
    }
}
