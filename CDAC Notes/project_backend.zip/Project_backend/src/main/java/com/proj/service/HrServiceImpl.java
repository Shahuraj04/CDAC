package com.proj.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.proj.customeException.NotFoundException;
import com.proj.dto.DeptResponseDTO;
import com.proj.dto.HRRequestDTO;
import com.proj.entity.Department;
import com.proj.entity.Hr;
import com.proj.repository.DeptRepository;
import com.proj.repository.HrRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
@Transactional

public class HrServiceImpl implements HrService {
	
	private final ModelMapper mapper;
	
	private final HrRepository hrRepository;
	
	private final DeptRepository deptrepo;
	

	@Override
	public List<Hr> getAllHr() {
		List<Hr> hr = hrRepository.findAll();
		
		if(hr.isEmpty()) {
			throw new NotFoundException("Hr not found");
		}
		
		return hr;
	}


	@Override
	public List<Hr> getByHrId(Long hrId) {
		List<Hr> hr = hrRepository.findByHrId(hrId);
		
		if(hr.isEmpty()) {
			throw new NotFoundException("Hr not found");
		}
		
		return hr;
	}


	@Override
	public DeptResponseDTO addHR(HRRequestDTO hrRequestDTO) {
		
		    Department department = deptrepo.findById(hrRequestDTO.getDeptId())
		            .orElseThrow(() -> new NotFoundException("Department not found"));

		 
		    Hr hr = new Hr();
		    hr.setHr_name(hrRequestDTO.getHr_name());
		    hr.setEmail(hrRequestDTO.getEmail());
		    hr.setPassword(hrRequestDTO.getPassword());
		    hr.setPhone(hrRequestDTO.getPhone());

		 
		    hr.setDepartment(department);

		    Hr save = hrRepository.save(hr);

		    return new DeptResponseDTO(
		            "Hr Added " + save.getHrId(),
		            "Successfully"
		    );
		}



	@Override
	public DeptResponseDTO deleteHrById(Long hrId) {
		Hr hr = hrRepository.findById(hrId).orElseThrow(()-> new RuntimeException("resource not found"));
		
		hrRepository.delete(hr);
		
		return new DeptResponseDTO("Department Deleted"+ hr.getHrId(), "successful");
		
	}

	@Override
	public DeptResponseDTO updateHr(Long hrId, HRRequestDTO hrDto) {

	    Hr hr = hrRepository.findById(hrId)
	            .orElseThrow(() -> new RuntimeException("Resource Not Found"));
	    
	    Department department = deptrepo.findById(hrDto.getDeptId()).orElseThrow(()->new NotFoundException("Data not Found"));

	    hr.setHr_name(hrDto.getHr_name());
	    hr.setEmail(hrDto.getEmail());
	    hr.setPassword(hrDto.getPassword());
	    hr.setPhone(hrDto.getPhone());
	    hr.setDepartment(department);

	    Hr updatedHr = hrRepository.save(hr);

	    return new DeptResponseDTO(
	            "HR Updated " + updatedHr.getHrId(),
	            "Successfully"
	    );
	}


	
}
