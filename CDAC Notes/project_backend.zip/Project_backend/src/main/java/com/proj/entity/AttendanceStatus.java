package com.proj.entity;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    HALF_DAY,
    LEAVE,
    LATE,
    WORK_FROM_HOME,
    HOLIDAY
}
