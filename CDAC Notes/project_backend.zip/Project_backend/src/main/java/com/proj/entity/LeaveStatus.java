package com.proj.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
