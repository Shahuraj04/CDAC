package com.proj.dto;

import java.time.LocalDate;

import com.proj.entity.AttendanceStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttendanceResponseDTO {

    private Long attendanceId;
    private LocalDate attendanceDate;
    private AttendanceStatus status;

    private Long empId;
    private String empName;
}
