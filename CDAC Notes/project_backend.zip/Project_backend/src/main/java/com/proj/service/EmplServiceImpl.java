package com.proj.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.proj.customeException.NotFoundException;
import com.proj.dto.DeptResponseDTO;
import com.proj.dto.EmpRequestDTO;
import com.proj.entity.Department;
import com.proj.entity.Employee;
import com.proj.entity.Hr;
import com.proj.repository.DeptRepository;
import com.proj.repository.EmpRepository;
import com.proj.repository.HrRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
@Transactional
public class EmplServiceImpl implements EmployeeService {

    private final EmpRepository empRepository;
    private final DeptRepository deptRepository;
    private final HrRepository hrRepository;

    @Override
    public DeptResponseDTO addEmployee(EmpRequestDTO empDTO) {

        Department dept = deptRepository.findById(empDTO.getDeptId())
                .orElseThrow(() -> new NotFoundException("Department not found"));

        Hr hr = hrRepository.findById(empDTO.getHrId())
                .orElseThrow(() -> new NotFoundException("HR not found"));

        Employee emp = new Employee();
        emp.setEmp_name(empDTO.getEmp_name());
        emp.setEmail(empDTO.getEmail());
        emp.setPassword(empDTO.getPassword());
        emp.setPhone(empDTO.getPhone());
        emp.setDesignation(empDTO.getDesignation());
        emp.setJoinDate(empDTO.getJoinDate());
        emp.setDepartment(dept);
        emp.setHr(hr);

        Employee saved = empRepository.save(emp);

        return new DeptResponseDTO(
                "Employee Added " + saved.getEmpId(),
                "Successfully"
        );
    }

    @Override
    public List<Employee> getAllEmployees() {
        List<Employee> list = empRepository.findAll();

        if (list.isEmpty()) {
            throw new NotFoundException("No employees found");
        }
        return list;
    }

    @Override
    public List<Employee> getEmployeeById(Long empId) {
        List<Employee> list = empRepository.findByEmpId(empId);

        if (list.isEmpty()) {
            throw new NotFoundException("Employee not found");
        }
        return list;
    }

    @Override
    public DeptResponseDTO deleteEmployeeById(Long empId) {

        Employee emp = empRepository.findById(empId)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        //  Soft delete happens here
        empRepository.delete(emp);

        return new DeptResponseDTO(
                "Employee Deleted " + emp.getEmpId(),
                "Successful"
        );
    }

    @Override
    public DeptResponseDTO updateEmployee(Long empId, EmpRequestDTO empDto) {

        Employee emp = empRepository.findById(empId)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        emp.setEmp_name(empDto.getEmp_name());
        emp.setEmail(empDto.getEmail());
        emp.setPassword(empDto.getPassword());
        emp.setPhone(empDto.getPhone());
        emp.setDesignation(empDto.getDesignation());
        emp.setJoinDate(empDto.getJoinDate());

        Employee updated = empRepository.save(emp);

        return new DeptResponseDTO(
                "Employee Updated " + updated.getEmpId(),
                "Successfully"
        );
    }
}
