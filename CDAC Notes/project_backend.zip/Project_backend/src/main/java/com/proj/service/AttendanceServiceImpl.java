package com.proj.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.proj.dto.AttendanceRequestDTO;
import com.proj.dto.AttendanceResponseDTO;
import com.proj.dto.AttendanceSummaryDTO;
import com.proj.entity.Attendance;
import com.proj.entity.AttendanceStatus;
import com.proj.repository.AttendanceRepository;
import com.proj.repository.EmpRepository;
import com.proj.repository.HrRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final EmpRepository employeeRepository;
    private final HrRepository hrRepository;
    private final ModelMapper modelMapper;

    // ================= MARK ATTENDANCE =================
    @Override
    public AttendanceResponseDTO markAttendance(AttendanceRequestDTO dto) {

        // Prevent future attendance
        if (dto.getAttendanceDate().isAfter(LocalDate.now())) {
            throw new RuntimeException("Future attendance is not allowed");
        }

        // Duplicate check
        boolean exists = attendanceRepository
                .existsByEmployee_EmpIdAndAttendanceDate(
                        dto.getEmpId(),
                        dto.getAttendanceDate()
                );

        if (exists) {
            throw new RuntimeException("Attendance already marked for this date");
        }

        Attendance attendance = new Attendance();
        attendance.setAttendanceDate(dto.getAttendanceDate());
        attendance.setEmployee(
                employeeRepository.findById(dto.getEmpId())
                        .orElseThrow(() -> new RuntimeException("Employee not found"))
        );
        attendance.setHr(
                hrRepository.findById(dto.getHrId())
                        .orElseThrow(() -> new RuntimeException("HR not found"))
        );

        // Calculate final status
        AttendanceStatus finalStatus =
                calculateAttendanceStatus(dto.getStatus(), dto.getAttendanceTime());

        attendance.setStatus(finalStatus);

        Attendance saved = attendanceRepository.save(attendance);

        AttendanceResponseDTO response =
                modelMapper.map(saved, AttendanceResponseDTO.class);

        response.setEmpId(saved.getEmployee().getEmpId());
        response.setEmpName(saved.getEmployee().getEmp_name());

        return response;
    }

    // ================= VIEW ATTENDANCE =================
    @Override
    public List<AttendanceResponseDTO> getAttendanceByEmployee(Long employeeId) {

        return attendanceRepository.findByEmployee_EmpId(employeeId)
                .stream()
                .map(att -> {
                    AttendanceResponseDTO dto =
                            modelMapper.map(att, AttendanceResponseDTO.class);
                    dto.setEmpId(att.getEmployee().getEmpId());
                    dto.setEmpName(att.getEmployee().getEmp_name());
                    return dto;
                })
                .toList();
    }

    // ================= MONTHLY SUMMARY =================
    @Override
    public AttendanceSummaryDTO getMonthlySummary(Long empId, int month, int year) {

        var employee = employeeRepository.findById(empId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        List<Object[]> data =
                attendanceRepository.getMonthlyAttendanceSummary(empId, month, year);

        long present = 0, absent = 0, half = 0, leave = 0, holiday = 0;

        for (Object[] row : data) {
            AttendanceStatus status = (AttendanceStatus) row[0];
            long count = (long) row[1];

            switch (status) {
                case PRESENT, WORK_FROM_HOME -> present += count;
                case HALF_DAY, LATE -> half += count;
                case ABSENT -> absent += count;
                case LEAVE -> leave += count;
                case HOLIDAY -> holiday += count;
            }
        }

        int totalDays = (int) (present + absent + half + leave + holiday);
        double workingDays = totalDays - holiday;

        double earnedDays = present + (half * 0.5);
        double percentage =
                workingDays == 0 ? 0 : (earnedDays / workingDays) * 100;

        AttendanceSummaryDTO summary = new AttendanceSummaryDTO();
        summary.setEmpId(empId);
        summary.setEmpName(employee.getEmp_name());
        summary.setTotalDays(totalDays);
        summary.setPresentDays(present);
        summary.setAbsentDays(absent);
        summary.setHalfDays(half);
        summary.setLeaveDays(leave);
        summary.setAttendancePercentage(
                Math.round(percentage * 100.0) / 100.0
        );

        return summary;
    }

    // ================= CORE BUSINESS LOGIC =================
    private AttendanceStatus calculateAttendanceStatus(
            AttendanceStatus requestedStatus,
            LocalTime attendanceTime
    ) {

        // Explicit HR-marked statuses
        if (requestedStatus == AttendanceStatus.WORK_FROM_HOME ||
            requestedStatus == AttendanceStatus.LEAVE ||
            requestedStatus == AttendanceStatus.HOLIDAY ||
            requestedStatus == AttendanceStatus.ABSENT) {
            return requestedStatus;
        }

        // If time not provided → default PRESENT
        if (attendanceTime == null) {
            return AttendanceStatus.PRESENT;
        }

        // Time-based rules
        if (attendanceTime.isAfter(LocalTime.of(13, 0))) {
            return AttendanceStatus.HALF_DAY;
        }

        if (attendanceTime.isAfter(LocalTime.of(10, 0))) {
            return AttendanceStatus.LATE;
        }

        return AttendanceStatus.PRESENT;
    }
}
