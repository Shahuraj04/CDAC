package com.proj.service;

import java.util.List;

import com.proj.dto.AttendanceRequestDTO;
import com.proj.dto.AttendanceResponseDTO;
import com.proj.dto.AttendanceSummaryDTO;

public interface AttendanceService {

    AttendanceResponseDTO markAttendance(AttendanceRequestDTO dto);

    List<AttendanceResponseDTO> getAttendanceByEmployee(Long employeeId);
    AttendanceSummaryDTO getMonthlySummary(Long empId, int month, int year);

}
