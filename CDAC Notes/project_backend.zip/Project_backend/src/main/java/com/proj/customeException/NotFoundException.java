package com.proj.customeException;

public class NotFoundException extends RuntimeException {

	public NotFoundException(String message) {
		super(message);
	}
	
	

}
