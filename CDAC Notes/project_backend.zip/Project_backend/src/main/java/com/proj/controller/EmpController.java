package com.proj.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proj.dto.DeptRequestDTO;
import com.proj.dto.DeptResponseDTO;
import com.proj.dto.EmpRequestDTO;
import com.proj.entity.Department;
import com.proj.entity.Employee;
import com.proj.service.EmployeeService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/employee")
@AllArgsConstructor

public class EmpController {
	
	private final EmployeeService employeeService;
	
	@PostMapping("/addemployee")
	public ResponseEntity<?> addEmployee(@RequestBody EmpRequestDTO deptDTO){
		
		try {
			
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(employeeService.addEmployee(deptDTO));
				
		}
		catch(RuntimeException e){
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}
	
	@GetMapping("allEmployees")
	public ResponseEntity<?> GetAllEmployees(){
		try {
			List<Employee> list = employeeService.getAllEmployees();
			return ResponseEntity.ok(list);
			
		}
		catch(RuntimeException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}
	
	@GetMapping("/id/{empId}")
	public ResponseEntity<?> GetEmployeeByID(@PathVariable Long empId ){
		try {
		List<Employee> list = employeeService.getEmployeeById(empId);
		return ResponseEntity.ok(list);
		}
		catch(RuntimeException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}	
	}
	
	@DeleteMapping("/delete/{empId}")
	public ResponseEntity<?> DeleteEmployeeById(@PathVariable Long empId){
		
		
		try {
			DeptResponseDTO dto = employeeService.deleteEmployeeById(empId); 
			return ResponseEntity.status(HttpStatus.ACCEPTED).body("Employee Deleted Successfully");
			}
			catch(RuntimeException e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
			}	
		
	}
	@PutMapping("/{empId}")
	public ResponseEntity<?> updateDepartment(@PathVariable Long empId, @RequestBody EmpRequestDTO empDto)
	{
		try {
			DeptResponseDTO dto = employeeService.updateEmployee(empId,empDto);
			return ResponseEntity.ok(dto);
		}
		catch(RuntimeException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}	
	}
	
	
	
}
