package com.proj.service;

import com.proj.dto.LeaveApplyRequestDTO;
import com.proj.dto.LeaveResponseDTO;
import com.proj.entity.LeaveStatus;

public interface LeaveService {

    LeaveResponseDTO applyLeave(LeaveApplyRequestDTO dto);

    LeaveResponseDTO updateLeaveStatus(
            Long leaveId,
            LeaveStatus status,
            Long hrId
    );
}
